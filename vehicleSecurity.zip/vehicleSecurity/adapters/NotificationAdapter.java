package com.vehiclesecurity.adapters;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.vehiclesecurity.R;
import com.vehiclesecurity.activities.NotificationCenterActivity;
import com.vehiclesecurity.models.Alert;
import com.vehiclesecurity.models.Vehicle;

import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.NotificationViewHolder> {

    private List<Alert> alerts;
    private NotificationCenterActivity activity;

    public NotificationAdapter(NotificationCenterActivity activity, List<Alert> alerts) {
        this.activity = activity;
        this.alerts = alerts;
    }

    @NonNull
    @Override
    public NotificationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_notification, parent, false);
        return new NotificationViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NotificationViewHolder holder, int position) {
        Alert alert = alerts.get(position);
        holder.tvAlertTime.setText(getTimeString(alert.getTimestamp()));
        holder.tvAlertStatus.setText(getStatusString(alert.getStatus()));

        // Load alert image using Glide
        Glide.with(holder.itemView.getContext())
                .load(alert.getCapturedImageUrl())
                .into(holder.ivAlertImage);

        // Set button visibility based on alert status
        if ("pending".equals(alert.getStatus())) {
            holder.btnIgnore.setVisibility(View.VISIBLE);
            holder.btnTakeAction.setVisibility(View.VISIBLE);
        } else {
            holder.btnIgnore.setVisibility(View.GONE);
            holder.btnTakeAction.setVisibility(View.GONE);
        }

        holder.btnIgnore.setOnClickListener(v -> {
            activity.onAlertAction(v, alert, "ignore");
        });

        holder.btnTakeAction.setOnClickListener(v -> {
            activity.onAlertAction(v, alert, "call");
        });
    }

    @Override
    public int getItemCount() {
        return alerts.size();
    }

    private String getTimeString(long timestamp) {
        // Implement time formatting
        return "Alert time: " + timestamp;
    }

    private String getStatusString(String status) {
        // Implement status formatting
        return "Status: " + status;
    }

    public class NotificationViewHolder extends RecyclerView.ViewHolder {
        public TextView tvAlertTime, tvAlertStatus;
        public ImageView ivAlertImage;
        public Button btnIgnore, btnTakeAction;

        public NotificationViewHolder(@NonNull View itemView) {
            super(itemView);
            tvAlertTime = itemView.findViewById(R.id.tv_alert_time);
            tvAlertStatus = itemView.findViewById(R.id.tv_alert_status);
            ivAlertImage = itemView.findViewById(R.id.iv_alert_image);
            btnIgnore = itemView.findViewById(R.id.btn_ignore);
            btnTakeAction = itemView.findViewById(R.id.btn_take_action);
        }
    }
}
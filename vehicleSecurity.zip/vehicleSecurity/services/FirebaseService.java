package com.vehiclesecurity.services;

import android.net.Uri;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.vehiclesecurity.models.Alert;
import com.vehiclesecurity.models.User;
import com.vehiclesecurity.models.Vehicle;
import com.vehiclesecurity.models.VehicleOwner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FirebaseService {
    private static FirebaseService instance;
    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;
    private FirebaseStorage mStorage;

    private FirebaseService() {
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        mStorage = FirebaseStorage.getInstance();
    }

    public static synchronized FirebaseService getInstance() {
        if (instance == null) {
            instance = new FirebaseService();
        }
        return instance;
    }

    // Authentication methods
    public Task<AuthResult> registerUser(String email, String password) {
        return mAuth.createUserWithEmailAndPassword(email, password);
    }

    public Task<AuthResult> loginUser(String email, String password) {
        return mAuth.signInWithEmailAndPassword(email, password);
    }

    public void logoutUser() {
        mAuth.signOut();
    }

    public FirebaseUser getCurrentUser() {
        return mAuth.getCurrentUser();
    }

    // User methods
    public Task<Void> createUser(User user) {
        return mDatabase.child("users").child(user.getUserId()).setValue(user);
    }

    public void getUserById(String userId, ValueEventListener listener) {
        mDatabase.child("users").child(userId).addListenerForSingleValueEvent(listener);
    }

    public Task<Void> updateUser(User user) {
        Map<String, Object> userValues = new HashMap<>();
        userValues.put("email", user.getEmail());
        userValues.put("phone", user.getPhone());
        userValues.put("name", user.getName());
        userValues.put("faceImageUrl", user.getFaceImageUrl());

        return mDatabase.child("users").child(user.getUserId()).updateChildren(userValues);
    }

    // Vehicle methods
    public DatabaseReference getVehicleReference() {
        return mDatabase.child("vehicles");
    }

    public Task<Void> createVehicle(Vehicle vehicle) {
        return mDatabase.child("vehicles").child(vehicle.getVehicleId()).setValue(vehicle);
    }

    public void getVehicleById(String vehicleId, ValueEventListener listener) {
        mDatabase.child("vehicles").child(vehicleId).addListenerForSingleValueEvent(listener);
    }

    public Task<Void> updateVehicle(Vehicle vehicle) {
        Map<String, Object> vehicleValues = new HashMap<>();
        vehicleValues.put("name", vehicle.getName());
        vehicleValues.put("number", vehicle.getNumber());
        vehicleValues.put("imageUrl", vehicle.getImageUrl());
        vehicleValues.put("numberPlateImageUrl", vehicle.getNumberPlateImageUrl());
        vehicleValues.put("ownerIds", vehicle.getOwnerIds());
        vehicleValues.put("parkedLocation", vehicle.getParkedLocation());
        vehicleValues.put("isParked", vehicle.isParked());

        return mDatabase.child("vehicles").child(vehicle.getVehicleId()).updateChildren(vehicleValues);
    }

    public void getVehiclesForUser(String userId, ValueEventListener listener) {
        mDatabase.child("vehicleOwners")
                .orderByChild("userId")
                .equalTo(userId)
                .addValueEventListener(listener);
    }

    // VehicleOwner methods
    public Task<Void> createVehicleOwner(VehicleOwner vehicleOwner) {
        return mDatabase.child("vehicleOwners").child(vehicleOwner.getId()).setValue(vehicleOwner);
    }

    public void getOwnersForVehicle(String vehicleId, ValueEventListener listener) {
        mDatabase.child("vehicleOwners")
                .orderByChild("vehicleId")
                .equalTo(vehicleId)
                .addValueEventListener(listener);
    }

    public Task<Void> removeVehicleOwner(String vehicleOwnerId) {
        return mDatabase.child("vehicleOwners").child(vehicleOwnerId).removeValue();
    }

    // Alert methods
    public Task<Void> createAlert(Alert alert) {
        return mDatabase.child("alerts").child(alert.getAlertId()).setValue(alert);
    }

    public void getAlertsForVehicle(String vehicleId, ValueEventListener listener) {
        mDatabase.child("alerts")
                .orderByChild("vehicleId")
                .equalTo(vehicleId)
                .addValueEventListener(listener);
    }

    public Task<Void> updateAlertStatus(String alertId, String status, String actionDetails) {
        Map<String, Object> alertValues = new HashMap<>();
        alertValues.put("status", status);
        alertValues.put("actionDetails", actionDetails);

        return mDatabase.child("alerts").child(alertId).updateChildren(alertValues);
    }

    // Storage methods
    public StorageReference getFaceImagesRef() {
        return mStorage.child("face_images");
    }

    public StorageReference getVehicleImagesRef() {
        return mStorage.child("vehicle_images");
    }

    public StorageReference getNumberPlateImagesRef() {
        return mStorage.child("numberplate_images");
    }

    public StorageReference getAlertImagesRef() {
        return mStorage.child("alert_images");
    }

    public UploadTask uploadImage(Uri imageUri, StorageReference storageRef) {
        return storageRef.putFile(imageUri);
    }

    public Task<Uri> getDownloadUrl(StorageReference storageRef) {
        return storageRef.getDownloadUrl();
    }
}
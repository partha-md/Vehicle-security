package com.vehiclesecurity.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.storage.StorageReference;
import com.vehiclesecurity.R;
import com.vehiclesecurity.models.Vehicle;
import com.vehiclesecurity.services.FirebaseService;

import java.io.IOException;

public class AddVehicleActivity extends AppCompatActivity {

    private EditText etVehicleName, etVehicleNumber, etOwnerName;
    private ImageView ivVehicleImage, ivNumberPlateImage;
    private Button btnAddVehicle;
    private ProgressBar progressBar;
    private FirebaseService firebaseService;
    private Uri vehicleImageUri, numberPlateImageUri;

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int PICK_NUMBER_PLATE_IMAGE_REQUEST = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vehicle);

        // Initialize Firebase service
        firebaseService = FirebaseService.getInstance();

        // Initialize UI components
        etVehicleName = findViewById(R.id.et_vehicle_name);
        etVehicleNumber = findViewById(R.id.et_vehicle_number);
        etOwnerName = findViewById(R.id.et_owner_name);
        ivVehicleImage = findViewById(R.id.iv_vehicle_image);
        ivNumberPlateImage = findViewById(R.id.iv_number_plate_image);
        btnAddVehicle = findViewById(R.id.btn_add_vehicle);
        progressBar = findViewById(R.id.progress_bar);

        // Set click listeners for image selection
        ivVehicleImage.setOnClickListener(v -> selectImage(PICK_IMAGE_REQUEST));
        ivNumberPlateImage.setOnClickListener(v -> selectImage(PICK_NUMBER_PLATE_IMAGE_REQUEST));

        // Set click listener for add vehicle button
        btnAddVehicle.setOnClickListener(v -> addVehicle());
    }

    private void selectImage(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            if (requestCode == PICK_IMAGE_REQUEST) {
                vehicleImageUri = selectedImageUri;
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                    ivVehicleImage.setImageBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (requestCode == PICK_NUMBER_PLATE_IMAGE_REQUEST) {
                numberPlateImageUri = selectedImageUri;
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                    ivNumberPlateImage.setImageBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void addVehicle() {
        String vehicleName = etVehicleName.getText().toString().trim();
        String vehicleNumber = etVehicleNumber.getText().toString().trim();
        String ownerName = etOwnerName.getText().toString().trim();

        // Validate input
        if (TextUtils.isEmpty(vehicleName)) {
            etVehicleName.setError("Vehicle name is required");
            return;
        }

        if (TextUtils.isEmpty(vehicleNumber)) {
            etVehicleNumber.setError("Vehicle number is required");
            return;
        }

        if (vehicleImageUri == null) {
            Toast.makeText(this, "Please select vehicle image", Toast.LENGTH_SHORT).show();
            return;
        }

        if (numberPlateImageUri == null) {
            Toast.makeText(this, "Please select number plate image", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        btnAddVehicle.setEnabled(false);

        FirebaseUser currentUser = firebaseService.getCurrentUser();
        if (currentUser == null) {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(this, "Please login to continue", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create new vehicle
        Vehicle vehicle = new Vehicle(
                firebaseService.getVehicleReference().push().getKey(),
                vehicleName,
                vehicleNumber,
                null,
                null,
                new ArrayList<>(),
                null,
                false
        );

        // Upload vehicle images to Firebase Storage
        StorageReference vehicleImagesRef = firebaseService.getVehicleImagesRef().child(currentUser.getUid() + "_" + System.currentTimeMillis() + ".jpg");
        StorageReference numberPlateImagesRef = firebaseService.getNumberPlateImagesRef().child(currentUser.getUid() + "_" + System.currentTimeMillis() + ".jpg");

        // Upload vehicle image
        firebaseService.uploadImage(vehicleImageUri, vehicleImagesRef)
                .addOnSuccessListener(taskSnapshot -> {
                    vehicleImagesRef.getDownloadUrl().addOnSuccessListener(vehicleImageUrl -> {
                        vehicle.setImageUrl(vehicleImageUrl.toString());

                        // Upload number plate image
                        firebaseService.uploadImage(numberPlateImageUri, numberPlateImagesRef)
                                .addOnSuccessListener(taskSnapshot1 -> {
                                    numberPlateImagesRef.getDownloadUrl().addOnSuccessListener(numberPlateImageUrl -> {
                                        vehicle.setNumberPlateImageUrl(numberPlateImageUrl.toString());

                                        // Add current user as owner
                                        vehicle.getOwnerIds().add(currentUser.getUid());

                                        // Save vehicle to database
                                        firebaseService.createVehicle(vehicle)
                                                .addOnCompleteListener(task -> {
                                                    if (task.isSuccessful()) {
                                                        // Create vehicle owner entry
                                                        VehicleOwner vehicleOwner = new VehicleOwner(
                                                                firebaseService.getVehicleReference().push().getKey(),
                                                                vehicle.getVehicleId(),
                                                                currentUser.getUid(),
                                                                true,
                                                                System.currentTimeMillis()
                                                        );
                                                        firebaseService.createVehicleOwner(vehicleOwner)
                                                                .addOnCompleteListener(task1 -> {
                                                                    progressBar.setVisibility(View.GONE);
                                                                    if (task1.isSuccessful()) {
                                                                        Toast.makeText(AddVehicleActivity.this, "Vehicle added successfully", Toast.LENGTH_SHORT).show();
                                                                        startActivity(new Intent(AddVehicleActivity.this, VehicleListActivity.class));
                                                                        finish();
                                                                    } else {
                                                                        Toast.makeText(AddVehicleActivity.this, "Failed to add vehicle: " + task1.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                                                        btnAddVehicle.setEnabled(true);
                                                                    }
                                                                });
                                                    } else {
                                                        progressBar.setVisibility(View.GONE);
                                                        Toast.makeText(AddVehicleActivity.this, "Failed to add vehicle: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                                        btnAddVehicle.setEnabled(true);
                                                    }
                                                });
                                    }).addOnFailureListener(e -> {
                                        progressBar.setVisibility(View.GONE);
                                        Toast.makeText(AddVehicleActivity.this, "Failed to get number plate image URL: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                        btnAddVehicle.setEnabled(true);
                                    });
                                }).addOnFailureListener(e -> {
                                    progressBar.setVisibility(View.GONE);
                                    Toast.makeText(AddVehicleActivity.this, "Failed to get vehicle image URL: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                    btnAddVehicle.setEnabled(true);
                                });
                    }).addOnFailureListener(e -> {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(AddVehicleActivity.this, "Failed to upload vehicle image: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        btnAddVehicle.setEnabled(true);
                    });
                }).addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(AddVehicleActivity.this, "Failed to upload vehicle image: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    btnAddVehicle.setEnabled(true);
                });
    }
}
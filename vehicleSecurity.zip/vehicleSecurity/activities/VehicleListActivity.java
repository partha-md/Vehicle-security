package com.vehiclesecurity.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.vehiclesecurity.R;
import com.vehiclesecurity.adapters.VehicleAdapter;
import com.vehiclesecurity.models.User;
import com.vehiclesecurity.models.Vehicle;
import com.vehiclesecurity.services.FirebaseService;

import java.util.ArrayList;
import java.util.List;

public class VehicleListActivity extends AppCompatActivity implements VehicleAdapter.OnItemClickListener {

    private RecyclerView rvVehicles;
    private VehicleAdapter vehicleAdapter;
    private List<Vehicle> vehicles;
    private ProgressBar progressBar;
    private TextView tvEmptyState;
    private FirebaseService firebaseService;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_list);

        // Initialize Firebase service
        firebaseService = FirebaseService.getInstance();

        // Initialize UI components
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        rvVehicles = findViewById(R.id.rv_vehicles);
        progressBar = findViewById(R.id.progress_bar);
        tvEmptyState = findViewById(R.id.tv_empty_state);

        // Set up RecyclerView
        vehicles = new ArrayList<>();
        vehicleAdapter = new VehicleAdapter(this, vehicles);
        rvVehicles.setLayoutManager(new LinearLayoutManager(this));
        rvVehicles.setAdapter(vehicleAdapter);

        // Load vehicles for current user
        currentUser = firebaseService.getCurrentUser();
        if (currentUser != null) {
            loadVehicles();
        } else {
            Toast.makeText(this, "Please login to continue", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }
    }

    private void loadVehicles() {
        progressBar.setVisibility(View.VISIBLE);
        firebaseService.getVehiclesForUser(currentUser.getUid(), new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                vehicles.clear();
                for (DataSnapshot vehicleOwnerSnapshot : dataSnapshot.getChildren()) {
                    String vehicleId = vehicleOwnerSnapshot.child("vehicleId").getValue(String.class);
                    firebaseService.getVehicleById(vehicleId, new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot vehicleSnapshot) {
                            if (vehicleSnapshot.exists()) {
                                Vehicle vehicle = vehicleSnapshot.getValue(Vehicle.class);
                                if (vehicle != null) {
                                    vehicles.add(vehicle);
                                    vehicleAdapter.notifyDataSetChanged();
                                    progressBar.setVisibility(View.GONE);
                                    if (vehicles.isEmpty()) {
                                        tvEmptyState.setVisibility(View.VISIBLE);
                                    } else {
                                        tvEmptyState.setVisibility(View.GONE);
                                    }
                                }
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(VehicleListActivity.this, "Failed to load vehicles: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(VehicleListActivity.this, "Failed to load vehicles: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onItemClick(Vehicle vehicle) {
        Intent intent = new Intent(this, VehicleDetailsActivity.class);
        intent.putExtra("vehicleId", vehicle.getVehicleId());
        startActivity(intent);
    }
}
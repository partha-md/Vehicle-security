package com.vehiclesecurity.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.vehiclesecurity.R;
import com.vehiclesecurity.adapters.NotificationAdapter;
import com.vehiclesecurity.models.Alert;
import com.vehiclesecurity.models.Vehicle;
import com.vehiclesecurity.services.FirebaseService;

import java.util.ArrayList;
import java.util.List;

public class NotificationCenterActivity extends AppCompatActivity {

    private RecyclerView rvNotifications;
    private NotificationAdapter notificationAdapter;
    private List<Alert> alerts;
    private ProgressBar progressBar;
    private TextView tvEmptyState;
    private FirebaseService firebaseService;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_center);

        // Initialize Firebase service
        firebaseService = FirebaseService.getInstance();

        // Initialize UI components
        rvNotifications = findViewById(R.id.rv_notifications);
        progressBar = findViewById(R.id.progress_bar);
        tvEmptyState = findViewById(R.id.tv_empty_state);

        // Set up RecyclerView
        alerts = new ArrayList<>();
        notificationAdapter = new NotificationAdapter(this, alerts);
        rvNotifications.setLayoutManager(new LinearLayoutManager(this));
        rvNotifications.setAdapter(notificationAdapter);

        // Load notifications
        currentUser = firebaseService.getCurrentUser();
        if (currentUser != null) {
            loadNotifications();
        } else {
            Toast.makeText(this, "Please login to continue", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }
    }

    private void loadNotifications() {
        progressBar.setVisibility(View.VISIBLE);
        firebaseService.getVehiclesForUser(currentUser.getUid(), new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                alerts.clear();
                for (DataSnapshot vehicleOwnerSnapshot : dataSnapshot.getChildren()) {
                    String vehicleId = vehicleOwnerSnapshot.child("vehicleId").getValue(String.class);
                    firebaseService.getAlertsForVehicle(vehicleId, new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            for (DataSnapshot alertSnapshot : dataSnapshot.getChildren()) {
                                Alert alert = alertSnapshot.getValue(Alert.class);
                                if (alert != null) {
                                    alerts.add(alert);
                                }
                            }
                            notificationAdapter.notifyDataSetChanged();
                            progressBar.setVisibility(View.GONE);
                            if (alerts.isEmpty()) {
                                tvEmptyState.setVisibility(View.VISIBLE);
                            } else {
                                tvEmptyState.setVisibility(View.GONE);
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(NotificationCenterActivity.this, "Failed to load notifications: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(NotificationCenterActivity.this, "Failed to load notifications: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void onAlertAction(View view, Alert alert, String action) {
        // Handle alert action
        if ("ignore".equals(action)) {
            firebaseService.updateAlertStatus(alert.getAlertId(), "ignored", null)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            loadNotifications();
                        }
                    });
        } else if ("call".equals(action)) {
            // Implement call functionality
            Toast.makeText(this, "Calling emergency contact", Toast.LENGTH_SHORT).show();
        }
    }
}
package com.vehiclesecurity.models;

public class User {
    private String userId;
    private String email;
    private String phone;
    private String name;
    private String faceImageUrl;
    private long createdAt;

    // Required empty constructor for Firebase
    public User() {
    }

    // Constructor, getters, and setters
    public User(String userId, String email, String phone, String name, String faceImageUrl, long createdAt) {
        this.userId = userId;
        this.email = email;
        this.phone = phone;
        this.name = name;
        this.faceImageUrl = faceImageUrl;
        this.createdAt = createdAt;
    }

    // Getters and setters
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getFaceImageUrl() { return faceImageUrl; }
    public void setFaceImageUrl(String faceImageUrl) { this.faceImageUrl = faceImageUrl; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
}
package com.vehiclesecurity.models;

public class VehicleOwner {
    private String id;
    private String vehicleId;
    private String userId;
    private boolean isMainOwner;
    private long addedAt;

    // Required empty constructor for Firebase
    public VehicleOwner() {
    }

    // Constructor, getters, and setters
    public VehicleOwner(String id, String vehicleId, String userId, boolean isMainOwner, long addedAt) {
        this.id = id;
        this.vehicleId = vehicleId;
        this.userId = userId;
        this.isMainOwner = isMainOwner;
        this.addedAt = addedAt;
    }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getVehicleId() { return vehicleId; }
    public void setVehicleId(String vehicleId) { this.vehicleId = vehicleId; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public boolean isMainOwner() { return isMainOwner; }
    public void setMainOwner(boolean mainOwner) { isMainOwner = mainOwner; }
    public long getAddedAt() { return addedAt; }
    public void setAddedAt(long addedAt) { this.addedAt = addedAt; }
}
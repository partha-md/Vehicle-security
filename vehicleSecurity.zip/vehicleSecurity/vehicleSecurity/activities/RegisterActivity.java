package com.vehiclesecurity.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.vehiclesecurity.R;
import com.vehiclesecurity.services.FirebaseService;
import com.vehiclesecurity.models.User;

public class RegisterActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPhone, etPassword, etConfirmPassword;
    private Button btnRegister;
    private TextView tvLogin;
    private ProgressBar progressBar;
    private FirebaseService firebaseService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize Firebase service
        firebaseService = FirebaseService.getInstance();

        // Initialize UI components
        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        etPhone = findViewById(R.id.et_phone);
        etPassword = findViewById(R.id.et_password);
        etConfirmPassword = findViewById(R.id.et_confirm_password);
        btnRegister = findViewById(R.id.btn_register);
        tvLogin = findViewById(R.id.tv_login);
        progressBar = findViewById(R.id.progress_bar);

        // Set click listeners
        btnRegister.setOnClickListener(v -> registerUser());
        tvLogin.setOnClickListener(v -> {
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
        });
    }

    private void registerUser() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();

        // Validate input
        if (TextUtils.isEmpty(name)) {
            etName.setError("Name is required");
            return;
        }

        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Email is required");
            return;
        }

        if (TextUtils.isEmpty(phone)) {
            etPhone.setError("Phone number is required");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Password is required");
            return;
        }

        if (!password.equals(confirmPassword)) {
            etConfirmPassword.setError("Passwords do not match");
            return;
        }

        if (password.length() < 6) {
            etPassword.setError("Password must be at least 6 characters");
            return;
        }

        // Show progress bar
        progressBar.setVisibility(View.VISIBLE);

        // Register user with Firebase
        firebaseService.registerUser(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // Registration successful
                        FirebaseUser user = firebaseService.getCurrentUser();
                        if (user != null) {
                            // Create user profile
                            User newUser = new User(
                                    user.getUid(),
                                    email,
                                    phone,
                                    name,
                                    null,
                                    System.currentTimeMillis()
                            );
                            firebaseService.createUser(newUser)
                                    .addOnCompleteListener(task1 -> {
                                        progressBar.setVisibility(View.GONE);
                                        if (task1.isSuccessful()) {
                                            // Start face registration activity
                                            Intent intent = new Intent(RegisterActivity.this, FaceRegistrationActivity.class);
                                            intent.putExtra("userId", user.getUid());
                                            startActivity(intent);
                                            finish();
                                        } else {
                                            // Failed to create user profile
                                            Toast.makeText(RegisterActivity.this, "Failed to create profile: " + task1.getException().getMessage(),
                                                    Toast.LENGTH_SHORT).show();
                                            firebaseService.logoutUser();
                                        }
                                    });
                        }
                    } else {
                        // Registration failed
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(RegisterActivity.this, "Registration failed: " + task.getException().getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
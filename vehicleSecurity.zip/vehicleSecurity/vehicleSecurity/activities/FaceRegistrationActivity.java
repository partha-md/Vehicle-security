package com.vehiclesecurity.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.CircleImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.storage.StorageReference;
import com.vehiclesecurity.R;
import com.vehiclesecurity.services.FirebaseService;
import com.vehiclesecurity.services.FaceRecognitionService;
import com.vehiclesecurity.utils.ImageUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;

public class FaceRegistrationActivity extends AppCompatActivity implements SurfaceHolder.Callback {

    private SurfaceView surfaceView;
    private Camera camera;
    private FaceRecognitionService faceRecognitionService;
    private FirebaseService firebaseService;
    private String userId;
    private CircleImageView facePreview;
    private Button btnCapture, btnContinue;
    private ProgressBar progressBar;
    private Bitmap capturedFaceBitmap;
    private Rect capturedFaceRect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_face_registration);

        // Get user ID from intent
        userId = getIntent().getStringExtra("userId");

        // Initialize services
        faceRecognitionService = FaceRecognitionService.getInstance();
        firebaseService = FirebaseService.getInstance();

        // Initialize UI components
        surfaceView = findViewById(R.id.camera_preview);
        facePreview = findViewById(R.id.face_preview);
        btnCapture = findViewById(R.id.btn_capture);
        btnContinue = findViewById(R.id.btn_continue);
        progressBar = findViewById(R.id.progress_bar);

        // Set up camera preview
        SurfaceHolder holder = surfaceView.getHolder();
        holder.addCallback(this);
        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

        // Set click listeners
        btnCapture.setOnClickListener(v -> captureFace());
        btnContinue.setOnClickListener(v -> continueRegistration());
    }

    private void captureFace() {
        if (camera != null) {
            camera.takePicture(null, null, (data, camera) -> {
                // Process image data
                Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                bitmap = ImageUtils.rotateBitmap(bitmap, 90); // Adjust rotation as needed

                // Detect faces in the image
                faceRecognitionService.detectFaces(bitmap, new FaceRecognitionService.FaceDetectionCallback() {
                    @Override
                    public void onFaceDetected(Bitmap faceBitmap, Rect faceRect) {
                        // Show preview of detected face
                        runOnUiThread(() -> {
                            facePreview.setImageBitmap(faceBitmap);
                            facePreview.setVisibility(View.VISIBLE);
                            btnContinue.setEnabled(true);
                            capturedFaceBitmap = faceBitmap;
                            capturedFaceRect = faceRect;
                        });
                    }

                    @Override
                    public void onNoFaceDetected() {
                        runOnUiThread(() -> {
                            Toast.makeText(FaceRegistrationActivity.this, "No face detected. Please try again.", Toast.LENGTH_SHORT).show();
                        });
                    }

                    @Override
                    public void onError(Exception e) {
                        runOnUiThread(() -> {
                            Toast.makeText(FaceRegistrationActivity.this, "Error detecting face: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        });
                    }
                });

                // Release camera
                camera.startPreview();
            });
        }
    }

    private void continueRegistration() {
        if (capturedFaceBitmap == null) {
            Toast.makeText(this, "Please capture your face first", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        btnContinue.setEnabled(false);

        // Convert bitmap to byte array
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        capturedFaceBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        // Upload face image to Firebase Storage
        StorageReference faceImagesRef = firebaseService.getFaceImagesRef().child(userId + ".jpg");
        UploadTask uploadTask = faceImagesRef.putBytes(data);

        uploadTask.addOnSuccessListener(taskSnapshot -> {
            faceImagesRef.getDownloadUrl().addOnSuccessListener(uri -> {
                // Update user profile with face image URL
                firebaseService.getUserById(userId, dataSnapshot -> {
                    if (dataSnapshot.exists()) {
                        User user = dataSnapshot.getValue(User.class);
                        if (user != null) {
                            user.setFaceImageUrl(uri.toString());
                            firebaseService.updateUser(user).addOnCompleteListener(task -> {
                                progressBar.setVisibility(View.GONE);
                                if (task.isSuccessful()) {
                                    Toast.makeText(FaceRegistrationActivity.this, "Face registration successful", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(FaceRegistrationActivity.this, LoginActivity.class));
                                    finish();
                                } else {
                                    Toast.makeText(FaceRegistrationActivity.this, "Failed to update profile: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    btnContinue.setEnabled(true);
                                }
                            });
                        }
                    }
                });
            }).addOnFailureListener(e -> {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(FaceRegistrationActivity.this, "Failed to get download URL: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                btnContinue.setEnabled(true);
            });
        }).addOnFailureListener(e -> {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(FaceRegistrationActivity.this, "Failed to upload face image: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            btnContinue.setEnabled(true);
        });
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        try {
            camera = Camera.open();
            camera.setPreviewDisplay(holder);
            camera.startPreview();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        if (holder.getSurface() == null) {
            return;
        }

        try {
            camera.stopPreview();
            camera.setPreviewDisplay(holder);
            camera.startPreview();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        if (camera != null) {
            camera.release();
            camera = null;
        }
    }
}
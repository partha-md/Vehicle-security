package com.vehiclesecurity.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.vehiclesecurity.R;
import com.vehiclesecurity.models.Vehicle;
import com.vehiclesecurity.services.FirebaseService;

public class VehicleDetailsActivity extends AppCompatActivity {

    private TextView tvVehicleName, tvVehicleNumber, tvNumberOfOwners, tvParkedLocation;
    private ImageView ivVehicleImage, ivNumberPlateImage;
    private Button btnAddOwner, btnRemoveOwnership, btnUpdateLocation;
    private FirebaseService firebaseService;
    private String vehicleId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_details);

        // Initialize Firebase service
        firebaseService = FirebaseService.getInstance();

        // Get vehicle ID from intent
        vehicleId = getIntent().getStringExtra("vehicleId");

        // Initialize UI components
        tvVehicleName = findViewById(R.id.tv_vehicle_name);
        tvVehicleNumber = findViewById(R.id.tv_vehicle_number);
        tvNumberOfOwners = findViewById(R.id.tv_number_of_owners);
        tvParkedLocation = findViewById(R.id.tv_parked_location);
        ivVehicleImage = findViewById(R.id.iv_vehicle_image);
        ivNumberPlateImage = findViewById(R.id.iv_number_plate_image);
        btnAddOwner = findViewById(R.id.btn_add_owner);
        btnRemoveOwnership = findViewById(R.id.btn_remove_ownership);
        btnUpdateLocation = findViewById(R.id.btn_update_location);

        // Load vehicle details
        loadVehicleDetails();
    }

    private void loadVehicleDetails() {
        firebaseService.getVehicleById(vehicleId, new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Vehicle vehicle = dataSnapshot.getValue(Vehicle.class);
                    if (vehicle != null) {
                        // Update UI with vehicle details
                        tvVehicleName.setText(vehicle.getName());
                        tvVehicleNumber.setText(vehicle.getNumber());
                        tvNumberOfOwners.setText(String.valueOf(vehicle.getOwnerIds().size()));
                        tvParkedLocation.setText(vehicle.getParkedLocation() != null ?
                                vehicle.getParkedLocation().get("lat") + ", " + vehicle.getParkedLocation().get("long") :
                                "Location not available");

                        // Load vehicle images using Glide
                        Glide.with(VehicleDetailsActivity.this)
                                .load(vehicle.getImageUrl())
                                .into(ivVehicleImage);

                        Glide.with(VehicleDetailsActivity.this)
                                .load(vehicle.getNumberPlateImageUrl())
                                .into(ivNumberPlateImage);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(VehicleDetailsActivity.this, "Failed to load vehicle details: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void onAddOwnerClick(View view) {
        // Implement add owner functionality
        Toast.makeText(this, "Add owner functionality coming soon", Toast.LENGTH_SHORT).show();
    }

    public void onRemoveOwnershipClick(View view) {
        // Implement remove ownership functionality
        Toast.makeText(this, "Remove ownership functionality coming soon", Toast.LENGTH_SHORT).show();
    }

    public void onUpdateLocationClick(View view) {
        // Implement update location functionality
        Toast.makeText(this, "Update location functionality coming soon", Toast.LENGTH_SHORT).show();
    }
}
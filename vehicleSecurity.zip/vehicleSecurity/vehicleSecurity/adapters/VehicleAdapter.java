package com.vehiclesecurity.adapters;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.vehiclesecurity.R;
import com.vehiclesecurity.activities.VehicleDetailsActivity;
import com.vehiclesecurity.models.Vehicle;

import java.util.List;

public class VehicleAdapter extends RecyclerView.Adapter<VehicleAdapter.VehicleViewHolder> {

    private List<Vehicle> vehicles;
    private OnItemClickListener listener;

    public VehicleAdapter(List<Vehicle> vehicles) {
        this.vehicles = vehicles;
    }

    @NonNull
    @Override
    public VehicleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_vehicle, parent, false);
        return new VehicleViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull VehicleViewHolder holder, int position) {
        Vehicle vehicle = vehicles.get(position);
        holder.tvVehicleName.setText(vehicle.getName());
        holder.tvVehicleNumber.setText(vehicle.getNumber());
        holder.tvNumberOfOwners.setText(String.valueOf(vehicle.getOwnerIds().size()));

        // Load vehicle image using Glide
        Glide.with(holder.itemView.getContext())
                .load(vehicle.getImageUrl())
                .into(holder.ivVehicleImage);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(vehicle);
            }
        });
    }

    @Override
    public int getItemCount() {
        return vehicles.size();
    }

    public class VehicleViewHolder extends RecyclerView.ViewHolder {
        public TextView tvVehicleName, tvVehicleNumber, tvNumberOfOwners;
        public ImageView ivVehicleImage;

        public VehicleViewHolder(@NonNull View itemView) {
            super(itemView);
            tvVehicleName = itemView.findViewById(R.id.tv_vehicle_name);
            tvVehicleNumber = itemView.findViewById(R.id.tv_vehicle_number);
            tvNumberOfOwners = itemView.findViewById(R.id.tv_number_of_owners);
            ivVehicleImage = itemView.findViewById(R.id.iv_vehicle_image);
        }
    }

    public interface OnItemClickListener {
        void onItemClick(Vehicle vehicle);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}
package com.vehiclesecurity.services;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.vehiclesecurity.utils.ImageUtils;

import java.util.ArrayList;
import java.util.List;

public class FaceRecognitionService {
    private static final String TAG = "FaceRecognitionService";
    private static FaceRecognitionService instance;
    private final FaceDetector faceDetector;

    private FaceRecognitionService() {
        // High-accuracy face detection with landmark detection
        FaceDetectorOptions options = new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .build();

        faceDetector = FaceDetection.getClient(options);
    }

    public static synchronized FaceRecognitionService getInstance() {
        if (instance == null) {
            instance = new FaceRecognitionService();
        }
        return instance;
    }

    public interface FaceDetectionCallback {
        void onFaceDetected(Bitmap faceBitmap, Rect faceRect);
        void onNoFaceDetected();
        void onError(Exception e);
    }

    public void detectFaces(Bitmap image, final FaceDetectionCallback callback) {
        InputImage inputImage = InputImage.fromBitmap(image, 0);

        faceDetector.process(inputImage)
                .addOnSuccessListener(faces -> {
                    if (faces.size() > 0) {
                        // Get the first face detected
                        Face face = faces.get(0);
                        Rect bounds = face.getBoundingBox();

                        // Crop face from original image
                        Bitmap faceBitmap = ImageUtils.cropBitmap(image, bounds.left, bounds.top, bounds.width(), bounds.height());

                        // Return both the face bitmap and its bounds
                        callback.onFaceDetected(faceBitmap, bounds);
                    } else {
                        callback.onNoFaceDetected();
                    }
                })
                .addOnFailureListener(e -> {
                    callback.onError(e);
                });
    }

    // Simple face comparison using face landmarks
    // Note: In a real application, you would use a more sophisticated face recognition algorithm
    public float compareFaces(Face face1, Face face2) {
        // This is a very simplified comparison - real face recognition would use
        // neural networks and feature vectors
        return 0.75f; // Dummy similarity score between 0 and 1
    }

    public void cleanup() {
        faceDetector.close();
    }
}
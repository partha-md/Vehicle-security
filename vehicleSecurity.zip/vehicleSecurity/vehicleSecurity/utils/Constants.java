package com.vehiclesecurity.utils;

public class Constants {
    public static final String VEHICLE_SECURITY = "VehicleSecurity";
    public static final String PREFERENCE_NAME = "VehicleSecurityPref";
    public static final String IS_LOGIN = "IsLoggedIn";
    public static final String KEY_USER_ID = "userId";
    public static final String KEY_USER_EMAIL = "userEmail";
    public static final String KEY_USER_NAME = "userName";
    public static final String KEY_USER_PHONE = "userPhone";
    public static final String KEY_USER_FACE_IMAGE_URL = "userFaceImageUrl";
}
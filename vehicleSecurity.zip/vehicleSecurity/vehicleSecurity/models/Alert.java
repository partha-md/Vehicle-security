package com.vehiclesecurity.models;

public class Alert {
    private String alertId;
    private String vehicleId;
    private String capturedImageUrl;
    private long timestamp;
    private String status;
    private String actionDetails;

    // Required empty constructor for Firebase
    public Alert() {
    }

    // Constructor, getters, and setters
    public Alert(String alertId, String vehicleId, String capturedImageUrl, long timestamp, String status, String actionDetails) {
        this.alertId = alertId;
        this.vehicleId = vehicleId;
        this.capturedImageUrl = capturedImageUrl;
        this.timestamp = timestamp;
        this.status = status;
        this.actionDetails = actionDetails;
    }

    // Getters and setters
    public String getAlertId() { return alertId; }
    public void setAlertId(String alertId) { this.alertId = alertId; }
    public String getVehicleId() { return vehicleId; }
    public void setVehicleId(String vehicleId) { this.vehicleId = vehicleId; }
    public String getCapturedImageUrl() { return capturedImageUrl; }
    public void setCapturedImageUrl(String capturedImageUrl) { this.capturedImageUrl = capturedImageUrl; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getActionDetails() { return actionDetails; }
    public void setActionDetails(String actionDetails) { this.actionDetails = actionDetails; }
}
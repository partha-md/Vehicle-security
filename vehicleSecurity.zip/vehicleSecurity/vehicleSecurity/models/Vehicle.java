package com.vehiclesecurity.models;

import java.util.List;
import java.util.Map;

public class Vehicle {
    private String vehicleId;
    private String name;
    private String number;
    private String imageUrl;
    private String numberPlateImageUrl;
    private List<String> ownerIds;
    private Map<String, Double> parkedLocation;
    private boolean isParked;

    // Required empty constructor for Firebase
    public Vehicle() {
    }

    // Constructor, getters, and setters
    public Vehicle(String vehicleId, String name, String number, String imageUrl, String numberPlateImageUrl, List<String> ownerIds, Map<String, Double> parkedLocation, boolean isParked) {
        this.vehicleId = vehicleId;
        this.name = name;
        this.number = number;
        this.imageUrl = imageUrl;
        this.numberPlateImageUrl = numberPlateImageUrl;
        this.ownerIds = ownerIds;
        this.parkedLocation = parkedLocation;
        this.isParked = isParked;
    }

    // Getters and setters
    public String getVehicleId() { return vehicleId; }
    public void setVehicleId(String vehicleId) { this.vehicleId = vehicleId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getNumber() { return number; }
    public void setNumber(String number) { this.number = number; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public String getNumberPlateImageUrl() { return numberPlateImageUrl; }
    public void setNumberPlateImageUrl(String numberPlateImageUrl) { this.numberPlateImageUrl = numberPlateImageUrl; }
    public List<String> getOwnerIds() { return ownerIds; }
    public void setOwnerIds(List<String> ownerIds) { this.ownerIds = ownerIds; }
    public Map<String, Double> getParkedLocation() { return parkedLocation; }
    public void setParkedLocation(Map<String, Double> parkedLocation) { this.parkedLocation = parkedLocation; }
    public boolean isParked() { return isParked; }
    public void setParked(boolean parked) { isParked = parked; }
}
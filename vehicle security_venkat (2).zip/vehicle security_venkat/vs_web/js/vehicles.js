

// DOM elements
const vehicleList = document.getElementById('vehicle-list');
const addVehicleBtn = document.getElementById('add-vehicle-btn');
const addVehicleModal = document.getElementById('add-vehicle-modal');
const addVehicleForm = document.getElementById('add-vehicle-form');
const vehicleImageInput = document.getElementById('vehicle-image');
const vehicleImagePreview = document.getElementById('vehicle-image-preview');
const numberPlateInput = document.getElementById('number-plate');
const numberPlatePreview = document.getElementById('number-plate-preview');

// Load vehicles when page loads
document.addEventListener('DOMContentLoaded', () => {
    auth.onAuthStateChanged(user => {
        if (user) {
            usernameElement.textContent = user.email || user.displayName || 'User';
            loadVehicles();
        } else {
            window.location.href = 'login.html';
        }
    });

    // File input event listeners for preview
    vehicleImageInput.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                vehicleImagePreview.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    });

    numberPlateInput.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                numberPlatePreview.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    });

    // Modal event listeners
    addVehicleBtn.addEventListener('click', () => {
        console.log("hello");
        
        addVehicleModal.style.display = 'block';
    });

    closeBtn.addEventListener('click', () => {
        addVehicleModal.style.display = 'none';
    });

    window.addEventListener('click', (e) => {
        if (e.target === addVehicleModal) {
            addVehicleModal.style.display = 'none';
        }
    });

    // Form submission
    addVehicleForm.addEventListener('submit', (e) => {
        e.preventDefault();
        addNewVehicle();
    });
});

// Load vehicles from Firebase
function loadVehicles() {
    const userId = firebase.auth().currentUser.uid;
    const vehiclesRef = database.ref(`users/${userId}/vehicles`);
    
    vehiclesRef.once('value').then(snapshot => {
        vehicleList.innerHTML = '';
        const vehicles = snapshot.val() || {};
        
        if (Object.keys(vehicles).length === 0) {
            vehicleList.innerHTML = '<div class="empty-state"><p>No vehicles registered yet</p><button id="add-first-vehicle" class="primary-btn">Add First Vehicle</button></div>';
            document.getElementById('add-first-vehicle').addEventListener('click', () => {
                addVehicleModal.style.display = 'block';
            });
            return;
        }
        
        Object.values(vehicles).forEach(vehicle => {
            const vehicleCard = document.createElement('div');
            vehicleCard.className = 'vehicle-card';
            vehicleCard.innerHTML = `
                <img src="${vehicle.imageUrl}" alt="${vehicle.name}">
                <div class="vehicle-info">
                    <h3>${vehicle.name}</h3>
                    <p><strong>Number:</strong> ${vehicle.number}</p>
                    <p><strong>Owners:</strong> ${vehicle.owners.length}</p>
                    <p><strong>Status:</strong> ${vehicle.isParked ? 'Parked' : 'Not Parked'}</p>
                    <div class="vehicle-actions">
                        <button class="view-btn" data-id="${vehicle.id}">View</button>
                        <button class="edit-btn" data-id="${vehicle.id}">Edit</button>
                        <button class="delete-btn" data-id="${vehicle.id}">Delete</button>
                    </div>
                </div>
            `;
            
            vehicleList.appendChild(vehicleCard);
        });

        // Add event listeners to action buttons
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const vehicleId = e.target.dataset.id;
                viewVehicleDetails(vehicleId);
            });
        });

        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const vehicleId = e.target.dataset.id;
                editVehicle(vehicleId);
            });
        });

        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const vehicleId = e.target.dataset.id;
                deleteVehicle(vehicleId);
            });
        });
    });
}

// Add new vehicle to Firebase
function addNewVehicle() {
    const userId = firebase.auth().currentUser.uid;
    const vehicleName = document.getElementById('vehicle-name').value;
    const vehicleNumber = document.getElementById('vehicle-number').value;
    const ownerName = document.getElementById('owner-name').value;
    const ownerPhone = document.getElementById('owner-phone').value;
    const vehicleImageFile = vehicleImageInput.files[0];
    const numberPlateFile = numberPlateInput.files[0];

    // Upload images to Firebase Storage
    const vehicleImageRef = storage.ref(`vehicles/${userId}/${Date.now()}_vehicle.jpg`);
    const numberPlateRef = storage.ref(`vehicles/${userId}/${Date.now()}_plate.jpg`);

    const uploadVehicleImage = vehicleImageRef.put(vehicleImageFile);
    const uploadNumberPlate = numberPlateRef.put(numberPlateFile);

    // Handle uploads and create vehicle record
    Promise.all([uploadVehicleImage, uploadNumberPlate])
        .then(() => {
            return Promise.all([
                vehicleImageRef.getDownloadURL(),
                numberPlateRef.getDownloadURL()
            ]);
        })
        .then(urls => {
            const vehicleData = {
                name: vehicleName,
                number: vehicleNumber,
                imageUrl: urls[0],
                numberPlateImageUrl: urls[1],
                ownerName: ownerName,
                ownerPhone: ownerPhone,
                ownerIds: [userId],
                isParked: false,
                createdAt: Date.now()
            };

            return database.ref(`users/${userId}/vehicles`).push(vehicleData);
        })
        .then(() => {
            addVehicleModal.style.display = 'none';
            addVehicleForm.reset();
            vehicleImagePreview.src = '';
            numberPlatePreview.src = '';
            loadVehicles();
            showNotification('Vehicle added successfully', 'success');
        })
        .catch(error => {
            showNotification('Error adding vehicle: ' + error.message, 'error');
        });
}

// View vehicle details
function viewVehicleDetails(vehicleId) {
    const userId = firebase.auth().currentUser.uid;
    const vehicleRef = database.ref(`users/${userId}/vehicles/${vehicleId}`);

    vehicleRef.once('value').then(snapshot => {
        const vehicle = snapshot.val();
        // Create and show details modal
        showVehicleDetailsModal(vehicle);
    });
}

// Edit vehicle information
function editVehicle(vehicleId) {
    // Implementation for editing vehicle details
    showNotification('Edit functionality coming soon', 'info');
}

// Delete vehicle
function deleteVehicle(vehicleId) {
    const userId = firebase.auth().currentUser.uid;
    const vehicleRef = database.ref(`users/${userId}/vehicles/${vehicleId}`);

    vehicleRef.remove()
        .then(() => {
            loadVehicles();
            showNotification('Vehicle deleted successfully', 'success');
        })
        .catch(error => {
            showNotification('Error deleting vehicle: ' + error.message, 'error');
        });
}

// Show notification
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Show vehicle details modal
function showVehicleDetailsModal(vehicle) {
    const modal = document.createElement('div');
    modal.className = 'details-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Vehicle Details</h2>
            <div class="details-container">
                <div class="details-image">
                    <img src="${vehicle.imageUrl}" alt="${vehicle.name}">
                </div>
                <div class="details-info">
                    <p><strong>Name:</strong> ${vehicle.name}</p>
                    <p><strong>Number:</strong> ${vehicle.number}</p>
                    <p><strong>Owner:</strong> ${vehicle.ownerName}</p>
                    <p><strong>Phone:</strong> ${vehicle.ownerPhone}</p>
                    <p><strong>Status:</strong> ${vehicle.isParked ? 'Parked' : 'Not Parked'}</p>
                    <p><strong>Added:</strong> ${new Date(vehicle.createdAt).toLocaleString()}</p>
                    <div class="details-actions">
                        <button class="edit-btn">Edit</button>
                        <button class="delete-btn">Delete</button>
                    </div>
                </div>
            </div>
            <div class="number-plate">
                <h3>Number Plate</h3>
                <img src="${vehicle.numberPlateImageUrl}" alt="Number Plate">
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    // Close modal
    modal.querySelector('.close').addEventListener('click', () => {
        document.body.removeChild(modal);
    });

    // Close when clicking outside
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            document.body.removeChild(modal);
        }
    });
}
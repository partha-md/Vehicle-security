// Initialize Firebase
firebase.initializeApp({
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    databaseURL: "YOUR_DATABASE_URL",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
});

const database = firebase.database();
const auth = firebase.auth();

// DOM elements
const usernameElement = document.getElementById('username');
const logoutBtn = document.getElementById('logout-btn');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const phoneInput = document.getElementById('phone');
const currentPasswordInput = document.getElementById('current-password');
const newPasswordInput = document.getElementById('new-password');
const confirmPasswordInput = document.getElementById('confirm-password');
const updateAccountBtn = document.getElementById('update-account-btn');
const emailNotificationsToggle = document.getElementById('email-notifications');
const smsNotificationsToggle = document.getElementById('sms-notifications');
const appNotificationsToggle = document.getElementById('app-notifications');
const notificationSoundSelect = document.getElementById('notification-sound');
const updateNotificationsBtn = document.getElementById('update-notifications-btn');
const emergencyContactsContainer = document.getElementById('emergency-contacts');
const addContactBtn = document.getElementById('add-contact-btn');
const addContactModal = document.getElementById('add-contact-modal');
const closeBtn = document.querySelector('.close');
const addContactForm = document.getElementById('add-contact-form');

// Load user settings when page loads
document.addEventListener('DOMContentLoaded', () => {
    auth.onAuthStateChanged(user => {
        if (user) {
            usernameElement.textContent = user.email || user.displayName || 'User';
            loadUserSettings();
            loadEmergencyContacts();
        } else {
            window.location.href = 'login.html';
        }
    });

    // Event listeners
    updateAccountBtn.addEventListener('click', updateAccountSettings);
    updateNotificationsBtn.addEventListener('click', updateNotificationSettings);
    addContactBtn.addEventListener('click', () => {
        addContactModal.style.display = 'block';
    });
    closeBtn.addEventListener('click', () => {
        addContactModal.style.display = 'none';
    });
    window.addEventListener('click', (e) => {
        if (e.target === addContactModal) {
            addContactModal.style.display = 'none';
        }
    });
    addContactForm.addEventListener('submit', addEmergencyContact);
});

// Load user settings from Firebase
function loadUserSettings() {
    const userId = auth.currentUser.uid;
    const userRef = database.ref(`users/${userId}`);

    userRef.once('value').then(snapshot => {
        const user = snapshot.val() || {};
        
        nameInput.value = user.name || '';
        emailInput.value = user.email || '';
        phoneInput.value = user.phone || '';
        
        // Load notification settings
        emailNotificationsToggle.checked = user.settings?.emailNotifications !== false;
        smsNotificationsToggle.checked = user.settings?.smsNotifications !== false;
        appNotificationsToggle.checked = user.settings?.appNotifications !== false;
        notificationSoundSelect.value = user.settings?.notificationSound || 'default';
    });
}

// Load emergency contacts from Firebase
function loadEmergencyContacts() {
    const userId = auth.currentUser.uid;
    const contactsRef = database.ref(`users/${userId}/emergencyContacts`);

    contactsRef.once('value').then(snapshot => {
        emergencyContactsContainer.innerHTML = '';
        const contacts = snapshot.val() || {};
        
        if (Object.keys(contacts).length === 0) {
            emergencyContactsContainer.innerHTML = '<p class="empty-state">No emergency contacts added yet</p>';
            return;
        }
        
        Object.values(contacts).forEach(contact => {
            const contactElement = document.createElement('div');
            contactElement.className = 'emergency-contact';
            contactElement.innerHTML = `
                <div class="emergency-contact-info">
                    <div class="emergency-contact-avatar">${contact.name.charAt(0)}</div>
                    <div class="emergency-contact-details">
                        <h4>${contact.name}</h4>
                        <p>${contact.phone}</p>
                        ${contact.relationship ? `<p class="relationship">${contact.relationship}</p>` : ''}
                    </div>
                </div>
                <div class="emergency-contact-actions">
                    <button class="delete-contact" data-id="${contact.id}">✕</button>
                </div>
            `;
            
            emergencyContactsContainer.appendChild(contactElement);
        });

        // Add delete event listeners
        document.querySelectorAll('.delete-contact').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const contactId = e.target.dataset.id;
                deleteEmergencyContact(contactId);
            });
        });
    });
}

// Update account settings
function updateAccountSettings() {
    const userId = auth.currentUser.uid;
    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const phone = phoneInput.value.trim();
    const currentPassword = currentPasswordInput.value;
    const newPassword = newPasswordInput.value;
    const confirmPassword = confirmPasswordInput.value;

    const userRef = database.ref(`users/${userId}`);

    // Update basic information
    userRef.update({
        name: name,
        email: email,
        phone: phone,
        updatedAt: Date.now()
    }).then(() => {
        showNotification('Account information updated successfully', 'success');
        
        // Update email if changed
        if (email !== auth.currentUser.email) {
            auth.currentUser.updateEmail(email)
                .then(() => {
                    showNotification('Email updated successfully', 'success');
                })
                .catch(error => {
                    showNotification('Error updating email: ' + error.message, 'error');
                });
        }
        
        // Update password if provided
        if (newPassword && confirmPassword) {
            if (newPassword !== confirmPassword) {
                showNotification('Passwords do not match', 'error');
                return;
            }
            
            auth.currentUser.updatePassword(newPassword)
                .then(() => {
                    showNotification('Password updated successfully', 'success');
                    currentPasswordInput.value = '';
                    newPasswordInput.value = '';
                    confirmPasswordInput.value = '';
                })
                .catch(error => {
                    showNotification('Error updating password: ' + error.message, 'error');
                });
        }
    }).catch(error => {
        showNotification('Error updating account: ' + error.message, 'error');
    });
}

// Update notification settings
function updateNotificationSettings() {
    const userId = auth.currentUser.uid;
    const emailNotifications = emailNotificationsToggle.checked;
    const smsNotifications = smsNotificationsToggle.checked;
    const appNotifications = appNotificationsToggle.checked;
    const notificationSound = notificationSoundSelect.value;

    const userRef = database.ref(`users/${userId}/settings`);

    userRef.update({
        emailNotifications: emailNotifications,
        smsNotifications: smsNotifications,
        appNotifications: appNotifications,
        notificationSound: notificationSound,
        updatedAt: Date.now()
    }).then(() => {
        showNotification('Notification settings updated successfully', 'success');
    }).catch(error => {
        showNotification('Error updating notification settings: ' + error.message, 'error');
    });
}

// Add emergency contact
function addEmergencyContact(e) {
    e.preventDefault();
    
    const userId = auth.currentUser.uid;
    const name = document.getElementById('contact-name').value.trim();
    const phone = document.getElementById('contact-phone').value.trim();
    const relationship = document.getElementById('contact-relationship').value.trim();

    if (!name || !phone) {
        showNotification('Name and phone are required', 'error');
        return;
    }

    const contactsRef = database.ref(`users/${userId}/emergencyContacts`);
    const newContactRef = contactsRef.push();

    newContactRef.set({
        name: name,
        phone: phone,
        relationship: relationship,
        createdAt: Date.now()
    }).then(() => {
        addContactModal.style.display = 'none';
        addContactForm.reset();
        loadEmergencyContacts();
        showNotification('Emergency contact added successfully', 'success');
    }).catch(error => {
        showNotification('Error adding emergency contact: ' + error.message, 'error');
    });
}

// Delete emergency contact
function deleteEmergencyContact(contactId) {
    const userId = auth.currentUser.uid;
    const contactRef = database.ref(`users/${userId}/emergencyContacts/${contactId}`);

    contactRef.remove().then(() => {
        loadEmergencyContacts();
        showNotification('Emergency contact deleted successfully', 'success');
    }).catch(error => {
        showNotification('Error deleting emergency contact: ' + error.message, 'error');
    });
}

// Show notification
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}
// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyD--Lmy0sk8FY_p3FhKyQ9A8eb6gqfOZZo",
    authDomain: "vehicle-security-system-c8c18.firebaseapp.com",
    databaseURL: "https://vehicle-security-system-c8c18-default-rtdb.firebaseio.com",
    projectId: "vehicle-security-system-c8c18",
    storageBucket: "vehicle-security-system-c8c18.firebasestorage.app",
    messagingSenderId: "911402132145",
    appId: "1:911402132145:web:72fe9fcbd4322bbd3cb890",
    measurementId: "G-D14HE0YD12"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Get Firebase services
const auth = firebase.auth();
const database = firebase.database();
const storage = firebase.storage();

// DOM elements
const usernameElement = document.getElementById('username');
const logoutBtn = document.getElementById('logout-btn');
const cameraGrid = document.getElementById('camera-grid');
const modal = document.getElementById('camera-details-modal');
const closeBtn = document.querySelector('.close');

// Initialize app
auth.onAuthStateChanged(user => {
    if (user) {
        // User is logged in
        usernameElement.textContent = user.email || user.displayName || 'User';
        loadLiveFeed();
    } else {
        // User is not logged in, redirect to login page
        window.location.href = 'login.html';
    }
});

// Logout functionality
logoutBtn.addEventListener('click', () => {
    auth.signOut().then(() => {
        window.location.href = 'login.html';
    }).catch(error => {
        console.error('Error logging out:', error);
    });
});

// Load live camera feed
function loadLiveFeed() {
    // For a real application, you would connect to actual camera feeds
    // This is a demo implementation with placeholder cameras
    const cameras = [
        { id: 1, name: 'Entrance', location: 'Main Entrance', status: 'active', hasAlert: true },
        { id: 2, name: 'Parking Lot', location: 'Parking Lot A', status: 'active', hasAlert: false },
        { id: 3, name: 'Exit', location: 'Main Exit', status: 'active', hasAlert: false },
        { id: 4, name: 'Garage', location: 'Garage 2', status: 'active', hasAlert: true }
    ];

    cameras.forEach(camera => {
        const cameraCard = document.createElement('div');
        cameraCard.className = 'camera-card';
        cameraCard.innerHTML = `
            <img src="https://placehold.co/300x200?text=Camera+${camera.id}" alt="Camera Feed">
            <div class="camera-info">
                <h3>${camera.name}</h3>
                <p>${camera.location}</p>
            </div>
            <div class="camera-status">${camera.status}</div>
            ${camera.hasAlert ? '<div class="alert-badge">!</div>' : ''}
        `;

        // Add click event to show larger view
        cameraCard.addEventListener('click', () => {
            showCameraDetails(camera);
        });

        cameraGrid.appendChild(cameraCard);
    });

    // Add periodic updates to simulate real-time data
    setInterval(() => {
        updateCameraStatuses();
    }, 5000);
}

// Show camera details modal
function showCameraDetails(camera) {
    const detailsContainer = document.getElementById('camera-details-container');
    detailsContainer.innerHTML = `
        <div class="camera-details-header">
            <h3>${camera.name}</h3>
            <span class="camera-location">${camera.location}</span>
        </div>
        <div class="camera-details-body">
            <div class="camera-large-view">
                <img src="https://placehold.co/800x600?text=Camera+${camera.id}+Live+Feed" alt="Camera Feed">
            </div>
            <div class="camera-details-info">
                <div class="camera-status-indicator">
                    <span>Status:</span>
                    <span class="status-badge ${camera.status === 'active' ? 'active' : 'inactive'}">${camera.status}</span>
                </div>
                <div class="vehicle-detection">
                    <h4>Vehicle Detection</h4>
                    <div class="detected-vehicle">
                        <img src="https://placehold.co/100x60?text=Vehicle" alt="Detected Vehicle">
                        <div class="vehicle-info">
                            <p><strong>Make:</strong> Toyota</p>
                            <p><strong>Model:</strong> Camry</p>
                            <p><strong>Color:</strong> Red</p>
                            <p><strong>License Plate:</strong> ABC1234</p>
                        </div>
                    </div>
                </div>
                <div class="owner-verification">
                    <h4>Owner Verification</h4>
                    <div class="verification-status">
                        <span>Status:</span>
                        <span class="status-badge ${camera.hasAlert ? 'alert' : 'verified'}">${camera.hasAlert ? 'Alert' : 'Verified'}</span>
                    </div>
                    ${camera.hasAlert ? `
                        <div class="alert-info">
                            <p>Unrecognized person detected</p>
                            <div class="alert-actions">
                                <button class="ignore-btn">Ignore</button>
                                <button class="action-btn">Take Action</button>
                            </div>
                        </div>
                    ` : ''}
                </div>
            </div>
        </div>
    `;

    // Add event listeners for alert actions
    if (camera.hasAlert) {
        document.querySelector('.ignore-btn').addEventListener('click', () => {
            // Handle ignore action
            showNotification('Alert ignored', 'info');
        });

        document.querySelector('.action-btn').addEventListener('click', () => {
            // Handle take action
            showNotification('Action taken: Alert reported to authorities', 'success');
        });
    }

    modal.style.display = 'block';
}

// Update camera statuses periodically
function updateCameraStatuses() {
    const cameraCards = document.querySelectorAll('.camera-card');
    cameraCards.forEach(card => {
        // Randomly change status for demo purposes
        const randomStatus = Math.random() > 0.7 ? 'active' : 'inactive';
        const randomAlert = Math.random() > 0.8;

        // Update status indicator
        const statusElement = card.querySelector('.camera-status');
        statusElement.textContent = randomStatus;
        statusElement.style.backgroundColor = randomStatus === 'active' ? '#4CAF50' : '#F44336';

        // Update alert badge
        const alertBadge = card.querySelector('.alert-badge');
        if (randomAlert) {
            if (!alertBadge) {
                const badge = document.createElement('div');
                badge.className = 'alert-badge';
                badge.textContent = '!';
                card.appendChild(badge);
            }
        } else if (alertBadge) {
            card.removeChild(alertBadge);
        }
    });
}

// Show notification
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;

    document.body.appendChild(notification);

    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Close modal when clicking outside content
modal.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});
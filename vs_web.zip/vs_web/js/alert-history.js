// Initialize Firebase
firebase.initializeApp({
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    databaseURL: "YOUR_DATABASE_URL",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
});

const database = firebase.database();

// DOM elements
const alertList = document.getElementById('alert-list');
const alertSearch = document.getElementById('alert-search');
const alertSearchBtn = document.getElementById('alert-search-btn');
const statusFilter = document.getElementById('status-filter');
const dateFilter = document.getElementById('date-filter');
const alertDetailsModal = document.getElementById('alert-details-modal');
const closeBtn = document.querySelector('.close');

// Load alerts when page loads
document.addEventListener('DOMContentLoaded', () => {
    auth.onAuthStateChanged(user => {
        if (user) {
            usernameElement.textContent = user.email || user.displayName || 'User';
            loadAlerts();
        } else {
            window.location.href = 'login.html';
        }
    });

    // Event listeners for filters
    alertSearchBtn.addEventListener('click', () => {
        loadAlerts();
    });

    alertSearch.addEventListener('keyup', (e) => {
        if (e.key === 'Enter') {
            loadAlerts();
        }
    });

    statusFilter.addEventListener('change', () => {
        loadAlerts();
    });

    dateFilter.addEventListener('change', () => {
        loadAlerts();
    });

    // Modal close event
    closeBtn.addEventListener('click', () => {
        alertDetailsModal.style.display = 'none';
    });

    window.addEventListener('click', (e) => {
        if (e.target === alertDetailsModal) {
            alertDetailsModal.style.display = 'none';
        }
    });
});

// Load alerts from Firebase
function loadAlerts() {
    const userId = firebase.auth().currentUser.uid;
    const searchTerm = alertSearch.value.toLowerCase();
    const status = statusFilter.value;
    const dateRange = dateFilter.value;

    const alertsRef = database.ref(`users/${userId}/alerts`);

    alertsRef.orderByChild('timestamp').once('value').then(snapshot => {
        alertList.innerHTML = '';
        const alerts = snapshot.val() || {};
        
        if (Object.keys(alerts).length === 0) {
            alertList.innerHTML = '<div class="empty-state"><p>No alerts found</p></div>';
            return;
        }

        // Filter alerts based on search and filters
        const filteredAlerts = Object.values(alerts).filter(alert => {
            // Status filter
            if (status !== 'all' && alert.status !== status) {
                return false;
            }

            // Date filter
            if (dateRange !== 'all') {
                const alertDate = new Date(alert.timestamp);
                const now = new Date();
                
                switch (dateRange) {
                    case 'today':
                        return alertDate.toDateString() === now.toDateString();
                    case 'week':
                        return now - alertDate <= 7 * 24 * 60 * 60 * 1000;
                    case 'month':
                        return now.getMonth() === alertDate.getMonth() && now.getFullYear() === alertDate.getFullYear();
                }
            }

            // Search filter
            if (searchTerm) {
                return alert.vehicleName.toLowerCase().includes(searchTerm) ||
                       alert.vehicleNumber.toLowerCase().includes(searchTerm);
            }

            return true;
        });

        // Sort alerts by timestamp (newest first)
        filteredAlerts.sort((a, b) => b.timestamp - a.timestamp);

        // Create alert cards
        filteredAlerts.forEach(alert => {
            const alertCard = document.createElement('div');
            alertCard.className = 'alert-card';
            alertCard.dataset.id = alert.id;
            alertCard.innerHTML = `
                <div class="alert-header">
                    <span class="alert-time">${new Date(alert.timestamp).toLocaleString()}</span>
                    <span class="alert-status status-${alert.status}">${getStatusText(alert.status)}</span>
                </div>
                <div class="alert-body">
                    <div class="alert-vehicle">
                        <img src="${alert.vehicleImageUrl}" alt="${alert.vehicleName}">
                        <div class="alert-vehicle-info">
                            <h3>${alert.vehicleName}</h3>
                            <p>${alert.vehicleNumber}</p>
                        </div>
                    </div>
                    <p>${alert.description}</p>
                    <img src="${alert.capturedImageUrl}" alt="Alert Image" class="alert-image">
                    <div class="alert-actions">
                        <button class="ignore-btn" data-id="${alert.id}">Ignore</button>
                        <button class="action-btn" data-id="${alert.id}">Take Action</button>
                    </div>
                </div>
            `;

            alertList.appendChild(alertCard);
        });

        // Add event listeners to action buttons
        document.querySelectorAll('.ignore-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const alertId = e.target.dataset.id;
                updateAlertStatus(alertId, 'ignored');
            });
        });

        document.querySelectorAll('.action-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const alertId = e.target.dataset.id;
                showActionMenu(alertId);
            });
        });

        // Add click event to open details
        document.querySelectorAll('.alert-card').forEach(card => {
            card.addEventListener('click', (e) => {
                if (!e.target.classList.contains('ignore-btn') && !e.target.classList.contains('action-btn')) {
                    const alertId = card.dataset.id;
                    loadAlertDetails(alertId);
                }
            });
        });
    });
}

// Load alert details
function loadAlertDetails(alertId) {
    const userId = firebase.auth().currentUser.uid;
    const alertRef = database.ref(`users/${userId}/alerts/${alertId}`);

    alertRef.once('value').then(snapshot => {
        const alert = snapshot.val();
        showAlertDetailsModal(alert);
    });
}

// Show alert details modal
function showAlertDetailsModal(alert) {
    const detailsContainer = document.getElementById('alert-details-container');
    detailsContainer.innerHTML = `
        <div class="alert-details-header">
            <h3>${alert.vehicleName}</h3>
            <span class="alert-time">${new Date(alert.timestamp).toLocaleString()}</span>
        </div>
        <div class="alert-details-body">
            <div class="alert-details-left">
                <div class="alert-vehicle-details">
                    <h3>Vehicle Details</h3>
                    <p><strong>Name:</strong> ${alert.vehicleName}</p>
                    <p><strong>Number:</strong> ${alert.vehicleNumber}</p>
                    <p><strong>Owner:</strong> ${alert.ownerName}</p>
                    <p><strong>Phone:</strong> ${alert.ownerPhone}</p>
                </div>
                <div class="alert-suspect-details">
                    <h3>Suspect Details</h3>
                    <p><strong>Status:</strong> ${getStatusText(alert.status)}</p>
                    <p><strong>Action Taken:</strong> ${alert.actionTaken || 'None'}</p>
                    <p><strong>Description:</strong> ${alert.description}</p>
                </div>
            </div>
            <div class="alert-details-right">
                <img src="${alert.capturedImageUrl}" alt="Alert Image" class="alert-image-large">
                <div class="alert-actions-large">
                    <button class="ignore-btn" data-id="${alert.id}">Ignore Alert</button>
                    <button class="action-btn" data-id="${alert.id}">Take Action</button>
                    <button class="contact-btn" data-phone="${alert.ownerPhone}">Contact Owner</button>
                </div>
            </div>
        </div>
    `;

    // Add event listeners to action buttons
    detailsContainer.querySelector('.ignore-btn').addEventListener('click', (e) => {
        const alertId = e.target.dataset.id;
        updateAlertStatus(alertId, 'ignored');
        alertDetailsModal.style.display = 'none';
    });

    detailsContainer.querySelector('.action-btn').addEventListener('click', (e) => {
        const alertId = e.target.dataset.id;
        showActionMenu(alertId);
    });

    detailsContainer.querySelector('.contact-btn').addEventListener('click', (e) => {
        const phone = e.target.dataset.phone;
        prompt(`Contact Owner: ${phone}`, phone);
    });

    alertDetailsModal.style.display = 'block';
}

// Show action menu
function showActionMenu(alertId) {
    const menu = document.createElement('div');
    menu.className = 'action-menu';
    menu.innerHTML = `
        <div class="action-item" data-action="call-police">
            <i class="fas fa-phone"></i>
            <span>Call Police</span>
        </div>
        <div class="action-item" data-action="contact-owner">
            <i class="fas fa-user"></i>
            <span>Contact Owner</span>
        </div>
        <div class="action-item" data-action="add-note">
            <i class="fas fa-edit"></i>
            <span>Add Note</span>
        </div>
    `;

    // Position menu near cursor
    menu.style.left = `${event.pageX}px`;
    menu.style.top = `${event.pageY}px`;

    document.body.appendChild(menu);

    // Add event listeners to menu items
    menu.querySelector('[data-action="call-police"]').addEventListener('click', () => {
        document.body.removeChild(menu);
        takeAction(alertId, 'Call Police');
    });

    menu.querySelector('[data-action="contact-owner"]').addEventListener('click', () => {
        document.body.removeChild(menu);
        takeAction(alertId, 'Contact Owner');
    });

    menu.querySelector('[data-action="add-note"]').addEventListener('click', () => {
        document.body.removeChild(menu);
        addNote(alertId);
    });

    // Remove menu when clicking outside
    const closeMenu = (e) => {
        if (!menu.contains(e.target)) {
            document.body.removeChild(menu);
            document.removeEventListener('click', closeMenu);
        }
    };
    document.addEventListener('click', closeMenu);
}

// Add note to alert
function addNote(alertId) {
    const note = prompt('Add a note to this alert:');
    if (note) {
        takeAction(alertId, `Added note: ${note}`);
    }
}

// Take action on alert
function takeAction(alertId, action) {
    updateAlertStatus(alertId, 'action-taken', action);
    showNotification(`Action taken: ${action}`, 'success');
}

// Update alert status
function updateAlertStatus(alertId, status, action = null) {
    const userId = firebase.auth().currentUser.uid;
    const alertRef = database.ref(`users/${userId}/alerts/${alertId}`);

    alertRef.update({
        status: status,
        actionTaken: action,
        updatedAt: Date.now()
    }).then(() => {
        loadAlerts();
    }).catch(error => {
        showNotification('Error updating alert: ' + error.message, 'error');
    });
}

// Show notification
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Get status text
function getStatusText(status) {
    switch (status) {
        case 'pending':
            return 'Pending';
        case 'ignored':
            return 'Ignored';
        case 'action-taken':
            return 'Action Taken';
        default:
            return status;
    }
}